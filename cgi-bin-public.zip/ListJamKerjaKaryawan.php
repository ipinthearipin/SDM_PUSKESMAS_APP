<?php
include 'koneksi.php';
header("Content-Type: application/json");

$kodeKaryawan = $_POST['kode_karyawan'];

$sql = "SELECT 
            sk.tanggal_shift,
            sk.lokasi_kerja,
            jk.nama_jam,
            jk.jam_masuk,
            jk.jam_pulang,
            jk.is_aktif
        FROM shift_karyawan sk
        JOIN jam_kerja jk ON sk.id_jam_kerja = jk.id_jam_kerja
        WHERE sk.kode_karyawan = ? 
        ORDER BY sk.tanggal_shift DESC";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("s", $kodeKaryawan);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
$stmt->close();
$koneksi->close();
?>
