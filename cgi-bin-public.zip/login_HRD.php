<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kodeKaryawan'];
$passwordKaryawan = $_POST['passwordKaryawan'];

// Menggunakan prepared statement untuk mencegah SQL injection
$login = mysqli_prepare($koneksi, "SELECT password_karyawan, role FROM karyawan WHERE kode_Karyawan ='$kodeKaryawan'");
mysqli_stmt_execute($login);

// Menggunakan prepared statement untuk mendapatkan hasil
mysqli_stmt_store_result($login);

// Mengambil hasil query
mysqli_stmt_bind_result($login, $hashedPassword, $role);

// Fetch hasil query
$result = mysqli_stmt_fetch($login);

// Tutup prepared statement
mysqli_stmt_close($login);

// Memeriksa apakah nomor_staff ditemukan dan password sesuai
if ($result) {
    // Memeriksa apakah peran adalah "hrd"
    if ($role === 'hrd' && $passwordKaryawan == $hashedPassword) {
        $kodeKaryawan_correct = $kodeKaryawan;
        $data = array(
            "message"=>"Login Berhasil!",
            "kode_karyawan" => $kodeKaryawan_correct
        );
    } else {
        $data = array(
            "message"=>"Kode Karyawan & Password Anda Salah!"
        );
    }
} else {
    $data = array(
        "message"=>"Kode Karyawan tidak ditemukan!"
    );
}

// Tutup koneksi
mysqli_close($koneksi);

echo json_encode($data);
?>
