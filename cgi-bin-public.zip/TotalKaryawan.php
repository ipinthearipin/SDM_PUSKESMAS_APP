<?php
include 'koneksi.php';
header("Content-Type: application/json");

// Query menghitung jumlah seluruh karyawan
$sql = "SELECT COUNT(*) AS total_karyawan FROM karyawan";
$result = $koneksi->query($sql);

if ($result && $row = $result->fetch_assoc()) {
    echo json_encode([
        "status" => "success",
        "total_karyawan" => intval($row['total_karyawan'])
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Gagal mengambil data: " . $koneksi->error
    ]);
}

$koneksi->close();
?>
