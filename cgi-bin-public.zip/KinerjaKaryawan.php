<?php
include 'koneksi.php';

$sql = "select SUM(lama_kinerja) as waktu, tanggal_kinerja from kinerja WHERE DATE_FORMAT(tanggal_kinerja,'%Y-%m') = DATE_FORMAT(CURDATE(),'%Y-%m') GROUP BY tanggal_kinerja";
$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    $totalScore = 0;
    $totalDay = 0;
    while($row = $result->fetch_assoc()) {
        $totalScore += $row['waktu'];
        $totalDay+=1;
    }
    $data['average'] = $totalScore/$totalDay;
} else {
    echo "Tidak ada data.";
}
echo json_encode($data);
mysqli_close($koneksi);

?>