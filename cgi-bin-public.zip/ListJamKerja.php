<?php
include 'koneksi.php';
header("Content-Type: application/json");

$sql = "SELECT 
            jk.id_jam_kerja,
            jk.nama_jam, 
            tp.nama_tipe, 
            jk.jam_masuk, 
            jk.jam_pulang, 
            CASE 
                WHEN jk.is_aktif = 1 THEN 'Ya' 
                ELSE 'Tidak' 
            END AS status_aktif
        FROM jam_kerja jk
        LEFT JOIN tipe_pegawai tp ON jk.id_tipe = tp.id_tipe";

$result = $koneksi->query($sql);

$data = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    $data = ["error" => "Tidak ada data jam kerja."];
}

echo json_encode($data);
mysqli_close($koneksi);
?>
