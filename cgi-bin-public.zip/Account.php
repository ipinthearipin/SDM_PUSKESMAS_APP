<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kodeKaryawan'];

$sql = "SELECT *, k.kode_karyawan as 'kode_karyawan' FROM karyawan k left join sip s on k.kode_karyawan = s.kode_karyawan left join str st on st.kode_karyawan = k.kode_karyawan where k.kode_karyawan = '$kodeKaryawan'";
$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    
} else {
    $data["message"] = "Tidak ada data.";
}
echo json_encode($data);
mysqli_close($koneksi);

?>