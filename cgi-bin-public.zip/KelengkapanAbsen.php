<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kode_karyawan'];

$sql = "SELECT COUNT(DISTINCT DATE(tanggal_absen)) as 'hadir' 
        FROM absen 
        WHERE kode_karyawan = '$kodeKaryawan' 
        AND type = 'in' 
        AND MONTH(tanggal_absen) = MONTH(CURDATE()) 
        AND YEAR(tanggal_absen) = YEAR(CURDATE())";

$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data['hadir'] = $row['hadir'];
} else {
    echo "Tidak ada data.";
}
echo json_encode($data);
mysqli_close($koneksi);
?>
