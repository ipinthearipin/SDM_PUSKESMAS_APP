<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kodeKaryawan'];
$namaKaryawan = $_POST['nama_karyawan'];
$emailKaryawan = $_POST['email_karyawan'];
$teleponKaryawan = $_POST['telepon_karyawan'];
$tanggalLahirKaryawan = $_POST['tanggal_lahir_karyawan'];
$gambarKaryawan = $_POST['gambar_karyawan'];

$date = date("Y-m-d", strtotime($tanggalLahirKaryawan));

$query = "UPDATE karyawan SET nama_karyawan = ?, email_karyawan = ?, telepon_karyawan = ?, tanggal_lahir_karyawan = ?, gambar_karyawan = ? WHERE kode_karyawan = ?";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ssssss", $namaKaryawan, $emailKaryawan, $teleponKaryawan, $date, $gambarKaryawan, $kodeKaryawan);
$result = mysqli_stmt_execute($stmt);

$data = array();
if ($result) {
    $count = mysqli_stmt_affected_rows($stmt);
    if ($count > 0) {
        $data = array(
            "message" => "Data Berhasil Diupdate"
        );
    } else {
        $data = array(
            "message" => "Data Tidak Berhasil Diupdate"
        );
    }
} else {
    $data = array(
        "message" => "Terjadi kesalahan saat memperbarui data"
    );
}
echo json_encode($data);
?>
