<?php
include 'koneksi.php';
header("Content-Type: application/json");

$action = isset($_POST['action']) ? $_POST['action'] : '';

$kode_karyawan = $_POST['kode_karyawan'];
$nama_karyawan = $_POST['nama_karyawan'];
$email_karyawan = $_POST['email_karyawan'];
$password_karyawan = $_POST['password_karyawan'];
$telepon_karyawan = $_POST['telepon_karyawan'];
$tanggal_lahir_karyawan = date("Y-m-d", strtotime($_POST['tanggal_lahir_karyawan']));
$nama_tipe = $_POST['nama_tipe']; // Nama tipe pegawai

// Ambil id_tipe dari nama_tipe
$query_tipe = "SELECT id_tipe FROM tipe_pegawai WHERE nama_tipe = ?";
$stmt_tipe = $koneksi->prepare($query_tipe);
$stmt_tipe->bind_param("s", $nama_tipe);
$stmt_tipe->execute();
$result_tipe = $stmt_tipe->get_result();
$row_tipe = $result_tipe->fetch_assoc();



$id_tipe = $row_tipe['id_tipe'];

// Verifikasi kode karyawan
if ($action == 'verify') {
    $query_check = "SELECT COUNT(*) AS total FROM karyawan WHERE kode_karyawan = ?";
    $stmt_check = mysqli_prepare($koneksi, $query_check);
    mysqli_stmt_bind_param($stmt_check, "s", $kode_karyawan);
    mysqli_stmt_execute($stmt_check);
    mysqli_stmt_bind_result($stmt_check, $total);
    mysqli_stmt_fetch($stmt_check);
    mysqli_stmt_close($stmt_check);

    if ($total > 0) {
        echo json_encode(["message" => "Kode karyawan sudah ada dalam database"]);
    } else {
        echo json_encode(["message" => "Apakah Anda yakin ingin menyimpan data ini?"]);
    }
    exit();
}

// Simpan data baru
if ($action == 'save') {
    $query = "INSERT INTO karyawan (kode_karyawan, nama_karyawan, email_karyawan, password_karyawan, telepon_karyawan, tanggal_lahir_karyawan, id_tipe) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "ssssssi", $kode_karyawan, $nama_karyawan, $email_karyawan, $password_karyawan, $telepon_karyawan, $tanggal_lahir_karyawan, $id_tipe);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(["message" => "Data Berhasil Diupload"]);
    } else {
        echo json_encode(["message" => "Data Tidak Berhasil Diupload"]);
    }

    mysqli_stmt_close($stmt);
}

mysqli_close($koneksi);
?>
