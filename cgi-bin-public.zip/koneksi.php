<?php
$hostname = "localhost";
$user = "sdmq3294";
$password = "+DfW8oT#Id621g";
$database = "sdmq3294_apksdm";

$koneksi = mysqli_connect($hostname, $user, $password, $database);

// Cek koneksi
if (!$koneksi) {
    die(json_encode(["error" => "Koneksi database gagal: " . mysqli_connect_error()]));
}

// Set karakter set
mysqli_set_charset($koneksi, "utf8");
?>
