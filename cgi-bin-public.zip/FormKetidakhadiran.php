<?php
    
    // $hostname = "localhost";
    // $user = "id21825478_absenpuskes";
    // $password = "SDMkodular123.";
    // $database = "id21825478_kodular";
    // $port = 3306;
    include 'koneksi.php';
    
    $konekci = mysqli_connect($hostname, $user, $password, $database);
    
    $NamaGambar = $_POST['NamaGambar'];
    $Jenis_Ketidakhadiran = $_POST['Jenis_Ketidakhadiran'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $Keterangan_Ketidakhadiran = $_POST['Keterangan_Ketidakhadiran'];
    $kodeKaryawan = $_POST['kodeKaryawan'];

    $date_mulai = date("Y-m-d", strtotime($tanggal_mulai));
    $date_selesai = date("Y-m-d", strtotime($tanggal_selesai));

    $query = "INSERT INTO form_ketidakhadiran (nama_gambar, jenis_ketidakhadiran, tanggal_mulai, tanggal_selesai, keterangan_ketidakhadiran, kode_karyawan) VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($konekci, $query);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssssss", $NamaGambar, $Jenis_Ketidakhadiran, $date_mulai, $date_selesai, $Keterangan_Ketidakhadiran, $kodeKaryawan);
        
        $result = mysqli_stmt_execute($stmt);
        
        // echo $result;
        
        if ($result) {
            $kodeKaryawan_correct = $kodeKaryawan;
            // $data = array(
            //     "message"=>"Data Berhasil Diupload",
            //     "kode_karyawan" => $kodeKaryawan_correct
            // );
            echo "Data Berhasil Diupload";
        } else {
            echo "Data Tidak Berhasil Diupload";
        }
        
        mysqli_stmt_close($stmt);
    } else {
        echo "Query preparation failed";
    }

    mysqli_close($konekci);
?>
