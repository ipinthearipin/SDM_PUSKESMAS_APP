<?php
include 'koneksi.php';

$sql = "SELECT kode_karyawan FROM karyawan";
$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        array_push($data, $row);
    }
} else {
    echo "Tidak ada data.";
}
echo json_encode($data);
mysqli_close($koneksi);

?>


