<?php
include 'koneksi.php';

$id = $_POST['id'];
$status = $_POST['status'];

$query = "UPDATE form_ketidakhadiran set hrd_status = ? WHERE idform_ketidakhadiran = ?";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "si", $status, $id);
$result = mysqli_stmt_execute($stmt);

if ($result) {
    $data = array(
        "message"=>"Data Berhasil Diupload, Mohon Refresh.."
    );
} else {
    $data = array(
        "message"=>"Data Tidak Berhasil Diupload"
    );
}
echo json_encode($data);

?>