<?php
include 'koneksi.php';
header("Content-Type: application/json");

// Ambil bulan dan tahun saat ini
$bulanIni = date('m');
$tahunIni = date('Y');

// Query durasi kerja per hari lalu jumlahkan hanya bulan ini
$sql = "
SELECT 
    a.kode_karyawan, 
    k.nama_karyawan, 
    SUM(a.durasi_menit) AS total_menit
FROM (
    SELECT 
        kode_karyawan,
        DATE(tanggal_absen) AS tanggal,
        TIMESTAMPDIFF(MINUTE,
            MIN(CASE WHEN type = 'in' THEN tanggal_absen END),
            MAX(CASE WHEN type = 'out' THEN tanggal_absen END)
        ) AS durasi_menit
    FROM absen
    WHERE type IN ('in', 'out')
      AND MONTH(tanggal_absen) = ? AND YEAR(tanggal_absen) = ?
    GROUP BY kode_karyawan, DATE(tanggal_absen)
    HAVING durasi_menit IS NOT NULL
) a
JOIN karyawan k ON k.kode_karyawan = a.kode_karyawan
GROUP BY a.kode_karyawan
ORDER BY total_menit DESC
LIMIT 10;
";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("ss", $bulanIni, $tahunIni);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            "kode_karyawan" => $row["kode_karyawan"],
            "nama_karyawan" => $row["nama_karyawan"],
            "total_menit" => strval($row["total_menit"])
        ];
    }
    echo json_encode(["status" => "success", "data" => $data]);
} else {
    echo json_encode(["status" => "error", "message" => $koneksi->error]);
}

$stmt->close();
$koneksi->close();
?>
