<?php
include 'koneksi.php';
header("Content-Type: application/json");

$kodeKaryawan = $_POST['kode_karyawan'];
$tanggalShift = $_POST['tanggal_shift'];
$namaJam = $_POST['nama_jam'];
$repeat = $_POST['repeat'] - 1;
$lokasiKerja = $_POST['lokasi_kerja']; // Tambahan lokasi

$tanggalShift = date("Y-m-d", strtotime($tanggalShift));
$endDate = date("Y-m-d", strtotime($tanggalShift . " + $repeat days"));

// cari id_jam_kerja
$queryId = "SELECT id_jam_kerja FROM jam_kerja WHERE nama_jam = ?";
$stmtId = $koneksi->prepare($queryId);
$stmtId->bind_param("s", $namaJam);
$stmtId->execute();
$resultId = $stmtId->get_result();

if ($resultId->num_rows > 0) {
    $row = $resultId->fetch_assoc();
    $idJamKerja = $row['id_jam_kerja'];

    // insert shift baru
    for ($i = 0; $i <= $repeat; $i++) {
        $currDate = date("Y-m-d", strtotime($tanggalShift . " + $i days"));
        $insertQuery = "INSERT INTO shift_karyawan (kode_karyawan, tanggal_shift, id_jam_kerja, lokasi_kerja) VALUES (?, ?, ?, ?)";
        $stmtIns = $koneksi->prepare($insertQuery);
        $stmtIns->bind_param("ssis", $kodeKaryawan, $currDate, $idJamKerja, $lokasiKerja);
        $stmtIns->execute();
    }

    echo json_encode(["message" => "Shift berhasil dimasukkan."]);
} else {
    echo json_encode(["message" => "Nama jam tidak ditemukan."]);
}

$stmtId->close();
$koneksi->close();
?>
