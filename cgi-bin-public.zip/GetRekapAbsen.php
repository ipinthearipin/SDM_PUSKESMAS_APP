<?php
include 'koneksi.php'; // koneksi mysqli

$kodeKaryawan = isset($_GET['kode_karyawan']) ? $_GET['kode_karyawan'] : '';
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : null;
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : null;

if (empty($kodeKaryawan)) {
    http_response_code(400);
    echo json_encode(['error' => 'Parameter kode_karyawan harus diisi']);
    exit;
}

$data = [];

$query = "SELECT absen.kode_karyawan, karyawan.nama_karyawan, tanggal_absen, type, lokasi_kerja, keterangan 
          FROM absen 
          JOIN karyawan ON absen.kode_karyawan = karyawan.kode_karyawan
          WHERE absen.kode_karyawan = ? ";

$params = [$kodeKaryawan];
$param_types = "s";

if ($bulan !== null && $tahun !== null) {
    $query .= " AND MONTH(tanggal_absen) = ? AND YEAR(tanggal_absen) = ? ";
    $param_types .= "ii";
    $params[] = (int)$bulan;
    $params[] = (int)$tahun;
}

$query .= " ORDER BY tanggal_absen DESC";

$stmt = $koneksi->prepare($query);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Gagal mempersiapkan query']);
    exit;
}

// Bind parameters dinamis
$stmt->bind_param($param_types, ...$params);

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

header('Content-Type: application/json');
echo json_encode($data);
?>
