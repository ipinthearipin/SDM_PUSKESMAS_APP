<?php
include 'koneksi.php';

$sql = "SELECT AVG(nilai) AS score FROM penilaian_kinerja_karyawan";
$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $rataRata = $row['score'];
    
    $data['score'] = $rataRata;
} else {
    echo "Tidak ada data.";
}
echo json_encode($data);
mysqli_close($koneksi);
?>
