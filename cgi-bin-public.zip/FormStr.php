<?php
include 'koneksi.php';

$nostr = $_POST['nomor_str'];
$image = $_POST['file_str'];
$date = $_POST['masa_berlaku'];
$kodekaryawan = $_POST['kode_karyawan'];

$date = date("Y-m-d", strtotime($date));

$query = "DELETE FROM str WHERE kode_karyawan = ?";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "s",$kodekaryawan);
$result = mysqli_stmt_execute($stmt);

$query = "INSERT INTO str (kode_karyawan, nomor_str, masa_berlaku, file_str) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ssss",$kodekaryawan, $nostr, $date, $image);
$result = mysqli_stmt_execute($stmt);

if ($result) {
    $data = array(
        "message"=>"Data Berhasil Diupload"
    );
} else {
    $data = array(
        "message"=>"Data Tidak Berhasil Diupload"
    );
}
echo json_encode($data);

?>