<?php
include 'koneksi.php';

$tahun = isset($_GET['tahun']) ? (int)$_GET['tahun'] : null;

if ($tahun === null) {
    http_response_code(400);
    echo "Parameter tahun wajib diisi.";
    exit;
}

header('Content-Type: text/csv; charset=utf-8');
header("Content-Disposition: attachment; filename=absen_tahun_{$tahun}.csv");

$output = fopen('php://output', 'w');
fputcsv($output, array('ID', 'Kode Karyawan', 'Tanggal Absen', 'Type', 'Lokasi Kerja', 'Keterangan', 'Jam Kerja'));

$query = "
    SELECT 
        a.id_absen, 
        a.kode_karyawan, 
        a.tanggal_absen, 
        a.type, 
        a.lokasi_kerja, 
        a.keterangan,
        jk.nama_jam AS jam_kerja
    FROM absen a
    LEFT JOIN shift_karyawan sk 
        ON a.kode_karyawan = sk.kode_karyawan AND DATE(a.tanggal_absen) = sk.tanggal_shift
    LEFT JOIN jam_kerja jk 
        ON sk.id_jam_kerja = jk.id_jam_kerja
    WHERE YEAR(a.tanggal_absen) = ?
    ORDER BY a.tanggal_absen DESC
";

$stmt = $koneksi->prepare($query);
$stmt->bind_param("i", $tahun);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    // fallback jika jam kerja tidak ditemukan
    $row['jam_kerja'] = empty($row['jam_kerja']) ? '-' : $row['jam_kerja'];
    fputcsv($output, $row);
}

fclose($output);
?>
