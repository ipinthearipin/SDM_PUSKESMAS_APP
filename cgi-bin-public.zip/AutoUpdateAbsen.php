<?php
include 'koneksi.php';
date_default_timezone_set("Asia/Jakarta");

$tanggalHariIni = date("Y-m-d");
$waktuSekarang = date("Y-m-d H:i:s");

// Ambil semua shift hari ini dari shift_karyawan + jam_kerja
$sqlShift = "
    SELECT s.kode_karyawan, s.tanggal_shift, jk.jam_masuk, jk.jam_pulang
    FROM shift_karyawan s
    JOIN jam_kerja jk ON s.id_jam_kerja = jk.id_jam_kerja
    WHERE s.tanggal_shift = '$tanggalHariIni'
";
$resultShift = $koneksi->query($sqlShift);

while ($shift = $resultShift->fetch_assoc()) {
    $kode = $shift['kode_karyawan'];
    $tanggalShift = $shift['tanggal_shift'];
    $jamMasuk = $shift['jam_masuk'];
    $jamPulang = $shift['jam_pulang'];

    // Hitung endTime (selesai shift)
    if ($jamPulang < $jamMasuk) {
        // Shift malam
        $endTime = date("Y-m-d H:i:s", strtotime("$tanggalShift +1 day $jamPulang"));
    } else {
        $endTime = date("Y-m-d H:i:s", strtotime("$tanggalShift $jamPulang"));
    }

    // Lewati jika shift belum selesai
    if ($waktuSekarang < $endTime) {
        continue;
    }

    // Cek apakah sudah ada absen otomatis type 'in' untuk tanggal tersebut
    $cekAbsen = $koneksi->query("
        SELECT COUNT(*) as total FROM absen
        WHERE kode_karyawan = '$kode'
        AND type = 'in'
        AND is_auto = 1
        AND DATE(tanggal_absen) = '$tanggalShift'
    ");
    $rowAbsen = $cekAbsen->fetch_assoc();

    if ($rowAbsen['total'] == 0) {
        $keterangan = "";

        // Cek cuti
        $cekCuti = $koneksi->query("
            SELECT * FROM form_ketidakhadiran
            WHERE kode_karyawan = '$kode'
            AND hrd_status = 'diterima'
            AND '$tanggalShift' BETWEEN tanggal_mulai AND tanggal_selesai
        ");
        if ($cekCuti->num_rows > 0) {
            $cuti = $cekCuti->fetch_assoc();
            $keterangan = $cuti['jenis_ketidakhadiran'];
        } else {
            // Cek libur nasional / weekend
            $cekLibur = $koneksi->query("
                SELECT * FROM hari_libur
                WHERE tanggal = '$tanggalShift' AND tipe IN ('Nasional', 'Weekend')
            ");
            if ($cekLibur->num_rows > 0) {
                $libur = $cekLibur->fetch_assoc();
                $keterangan = "Libur - " . $libur['tipe'];
            } else {
                // Cek jika kemarin ada 2 shift
                $kemarin = date("Y-m-d", strtotime("$tanggalShift -1 day"));
                $cekKemarin = $koneksi->query("
                    SELECT COUNT(*) as total FROM shift_karyawan
                    WHERE kode_karyawan = '$kode' AND tanggal_shift = '$kemarin'
                ");
                $rowKemarin = $cekKemarin->fetch_assoc();

                if ($rowKemarin['total'] >= 2) {
                    $keterangan = "Libur (2 Shift Kemarin)";
                } else {
                    $keterangan = "Tidak Hadir";
                }
            }
        }

        // Amankan keterangan untuk database
        $keterangan = mysqli_real_escape_string($koneksi, $keterangan);

        // Simpan ke tabel absen (auto)
        $koneksi->query("
            INSERT INTO absen (kode_karyawan, tanggal_absen, type, lokasi_kerja, keterangan, is_auto)
            VALUES ('$kode', NOW(), 'in', '-', '$keterangan', 1)
        ");

        // Logging untuk pemantauan cron
        file_put_contents("auto-absen-log.txt", "[" . date("Y-m-d H:i:s") . "] $kode - $keterangan\n", FILE_APPEND);
    }
}

echo json_encode(["status" => "success", "message" => "Auto update absensi selesai."]);
$koneksi->close();
