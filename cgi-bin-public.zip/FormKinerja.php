<?php
include 'koneksi.php';

$name = $_POST['name'];
$image = $_POST['image'];
$date = $_POST['date'];
$time = $_POST['time'];
$note = $_POST['note'];
$kodeKaryawan = $_POST['kode_karyawan'];

$date = date("Y-m-d", strtotime($date));

$query = "INSERT INTO kinerja (nama_kinerja, tanggal_kinerja, lama_kinerja, catatan_tambahan, nama_gambar_kinerja, kode_karyawan) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ssisss", $name, $date, $time, $note, $image, $kodeKaryawan);
$result = mysqli_stmt_execute($stmt);

$data = array();
if ($result) {
    $data = array(
        "message"=>"Data Berhasil Diupload"
    );
} else {
    $data = array(
        "message"=>"Data Tidak Berhasil Diupload"
    );
}
echo json_encode($data);

?>