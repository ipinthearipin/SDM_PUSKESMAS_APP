<?php
include 'koneksi.php';
// $hostname = "localhost";
// $user = "id21825478_absenpuskes";
// $password = "SDMkodular123.";
// $database = "id21825478_kodular";
// $port = 3306;

$konekci = mysqli_connect($hostname, $user, $password, $database);

// Query untuk mengambil data
$sql = "SELECT * FROM form_ketidakhadiran fk 
        JOIN karyawan k ON fk.kode_karyawan = k.kode_karyawan";
$result = $konekci->query($sql);

// Menampilkan data
$data = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        array_push($data, $row);
    }
}

echo json_encode($data);

mysqli_close($konekci);
?>
