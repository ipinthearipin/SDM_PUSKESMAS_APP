<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kode_karyawan'];

// Query untuk mengambil nilai terbaru setiap bulan
$sql = "
    SELECT AVG(subquery.nilai) AS 'score'
    FROM (
        SELECT pk.nilai
        FROM penilaian_kinerja_karyawan pk
        WHERE pk.kode_karyawan = '$kodeKaryawan'
        AND pk.tanggal_input IN (
            SELECT MAX(tanggal_input)
            FROM penilaian_kinerja_karyawan
            WHERE kode_karyawan = '$kodeKaryawan'
            GROUP BY YEAR(tanggal_input), MONTH(tanggal_input)
        )
    ) AS subquery
";

$result = $koneksi->query($sql);
$data = array();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data["score"] = number_format($row["score"], 1);
} else {
    $data["score"] = 0;
}

echo json_encode($data);
mysqli_close($koneksi);
?>
