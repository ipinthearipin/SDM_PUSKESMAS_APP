<?php
include 'koneksi.php';
header("Content-Type: application/json");

$action = $_POST['action']; // 'update' atau 'delete'

if ($action == 'update') {
    $idShift = $_POST['id'];
    $namaJam = $_POST['nama_jam'];
    $tanggalShift = $_POST['tanggal_shift'];
    $lokasiKerja = $_POST['lokasi_kerja'];

    // Cari ID jam kerja
    $stmtJam = $koneksi->prepare("SELECT id_jam_kerja FROM jam_kerja WHERE nama_jam = ?");
    $stmtJam->bind_param("s", $namaJam);
    $stmtJam->execute();
    $resultJam = $stmtJam->get_result();

    if ($resultJam->num_rows > 0) {
        $rowJam = $resultJam->fetch_assoc();
        $idJamKerja = $rowJam['id_jam_kerja'];

        $stmtUpdate = $koneksi->prepare("UPDATE shift_karyawan SET tanggal_shift = ?, id_jam_kerja = ?, lokasi_kerja = ? WHERE id = ?");
        $stmtUpdate->bind_param("sisi", $tanggalShift, $idJamKerja, $lokasiKerja, $idShift);

        if ($stmtUpdate->execute()) {
            echo json_encode(["message" => "Shift berhasil diupdate."]);
        } else {
            echo json_encode(["message" => "Gagal update shift."]);
        }
    } else {
        echo json_encode(["message" => "Nama jam tidak ditemukan."]);
    }

    $stmtJam->close();

} elseif ($action == 'delete') {
    $idShift = $_POST['id'];

    $stmtDel = $koneksi->prepare("DELETE FROM shift_karyawan WHERE id = ?");
    $stmtDel->bind_param("i", $idShift);

    if ($stmtDel->execute()) {
        echo json_encode(["message" => "Shift berhasil dihapus."]);
    } else {
        echo json_encode(["message" => "Gagal hapus shift."]);
    }

    $stmtDel->close();

} else {
    echo json_encode(["message" => "Action tidak valid."]);
}

$koneksi->close();
?>
