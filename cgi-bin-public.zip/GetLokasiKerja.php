<?php
include 'koneksi.php';

$kode = $_GET['kode_karyawan'];
$tanggal = date('Y-m-d');

$query = "SELECT lokasi_kerja FROM shift_karyawan WHERE kode_karyawan = ? AND tanggal_shift = ?";
$stmt = $koneksi->prepare($query);
$stmt->bind_param("ss", $kode, $tanggal);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $lokasi = $result->fetch_assoc();
    echo json_encode(["status" => "success", "lokasi_kerja" => $lokasi['lokasi_kerja']]);
} else {
    echo json_encode(["status" => "error", "message" => "Lokasi tidak ditemukan"]);
}
