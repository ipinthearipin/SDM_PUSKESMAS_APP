<?php
include 'koneksi.php';

header('Content-Type: application/json');

$kodeKaryawan = $_POST['kode_karyawan'];
$data = array();

// Gunakan Prepared Statement untuk keamanan
$stmt = $koneksi->prepare("SELECT tanggal_absen FROM absen 
                            WHERE kode_karyawan = ? 
                            AND DATE(tanggal_absen) = CURDATE() 
                            AND type = 'in' 
                            ORDER BY tanggal_absen DESC 
                            LIMIT 1");
$stmt->bind_param("s", $kodeKaryawan);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data["in"] = $row["tanggal_absen"];
    $latestCheckIn = $row["tanggal_absen"];
} else {
    $data["in"] = "";
    $latestCheckIn = null;
}
$stmt->close();

// Ambil check-out setelah check-in terbaru jika ada check-in hari ini
if ($latestCheckIn) {
    $stmt = $koneksi->prepare("SELECT tanggal_absen FROM absen 
                                WHERE kode_karyawan = ? 
                                AND DATE(tanggal_absen) = CURDATE() 
                                AND type = 'out' 
                                AND tanggal_absen > ? 
                                ORDER BY tanggal_absen ASC 
                                LIMIT 1");
    $stmt->bind_param("ss", $kodeKaryawan, $latestCheckIn);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $data["out"] = $row["tanggal_absen"];
    } else {
        $data["out"] = "";
    }
    $stmt->close();
} else {
    $data["out"] = "";
}

// Output JSON
echo json_encode($data);

// Tutup koneksi database
$koneksi->close();
?>
