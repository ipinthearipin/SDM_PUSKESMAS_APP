<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kode_karyawan'];
$score = $_POST['nilai'];
$note = $_POST['keterangan'];

$date = date("Y-m-d");

// clear old score
$query = "DELETE FROM penilaian_kinerja_karyawan WHERE kode_karyawan = ? AND DATE_FORMAT(tanggal_input,'%Y-%m') = DATE_FORMAT(?,'%Y-%m')";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ss", $kodeKaryawan, $date);
$result = mysqli_stmt_execute($stmt);

// insert new score
$query = "INSERT INTO penilaian_kinerja_karyawan (tanggal_input, kode_karyawan, nilai, keterangan) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ssis", $date, $kodeKaryawan, $score, $note);
$result = mysqli_stmt_execute($stmt);

if ($result) {
    $data = array(
        "message"=>"Data Berhasil Diupload"
    );
} else {
    $data = array(
        "message"=>"Data Tidak Berhasil Diupload"
    );
}
echo json_encode($data);
?>