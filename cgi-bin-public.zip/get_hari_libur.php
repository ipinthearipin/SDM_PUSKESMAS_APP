<?php
header('Content-Type: application/json');
include 'koneksi.php';

if (isset($_GET['tanggal'])) {
    $datePicked = $_GET['tanggal'];

    // Query data libur berdasarkan tanggal (ambil semua kolom)
    $stmt = $koneksi->prepare("SELECT * FROM hari_libur WHERE tanggal = ?");
    $stmt->bind_param("s", $datePicked);
    $stmt->execute();

    $result = $stmt->get_result();
    $data = [];

    while ($row = $result->fetch_assoc()) {
        // Hindari duplikat
        if (!in_array($row, $data)) {
            $data[] = $row;
        }
    }

    echo json_encode($data);
} else {
    echo json_encode(["error" => "Parameter tanggal tidak ditemukan"]);
}
?>
