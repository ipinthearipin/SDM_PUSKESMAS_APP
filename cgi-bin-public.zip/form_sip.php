<?php
include 'koneksi.php';

$image = $_POST['nama_gambar_sip'];
$date = $_POST['masa_berlaku_sip'];
$nosip = $_POST['no_sip'];
$kodekaryawan = $_POST['kode_karyawan'];

$date = date("Y-m-d", strtotime($date));

$query = "DELETE FROM sip WHERE kode_karyawan = ?";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "s",$kodekaryawan);
$result = mysqli_stmt_execute($stmt);

$query = "INSERT INTO sip (nama_gambar_sip, masa_berlaku_sip, no_sip, kode_karyawan) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ssss", $image, $date, $nosip, $kodekaryawan);
$result = mysqli_stmt_execute($stmt);

if ($result) {
    $data = array(
        "message"=>"Data Berhasil Diupload"
    );
} else {
    $data = array(
        "message"=>"Data Tidak Berhasil Diupload"
    );
}
echo json_encode($data);

?>