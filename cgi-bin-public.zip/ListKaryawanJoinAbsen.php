$sql = "SELECT 
    k.kode_karyawan, 
    k.nama_karyawan, 
    DATE(a.tanggal_absen) AS Tanggal_Absen,
    TIME(a.tanggal_absen) AS Jam_Absen,
    a.type AS Type,
    a.lokasi_kerja AS Lokasi_Kerja,
    CASE 
        WHEN sk.id_shift = 1 AND a.type = 'in' AND TIME(a.tanggal_absen) <= '07:30:00' THEN 'Tepat Waktu'
        WHEN sk.id_shift = 1 AND a.type = 'out' AND TIME(a.tanggal_absen) >= '14:00:00' THEN 'Pulang Tepat Waktu'
        WHEN sk.id_shift = 1 AND a.type = 'in' AND TIME(a.tanggal_absen) > '07:30:00' THEN CONCAT('Terlambat (', HOUR(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' jam ', MINUTE(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' menit ', SECOND(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' detik)')
        WHEN sk.id_shift = 1 AND a.type = 'out' AND TIME(a.tanggal_absen) < '14:00:00' THEN CONCAT('Pulang Lebih Cepat (', HOUR(TIMEDIFF('14:00:00', TIME(a.tanggal_absen))), ' jam ', MINUTE(TIMEDIFF('14:00:00', TIME(a.tanggal_absen))), ' menit ', SECOND(TIMEDIFF('14:00:00', TIME(a.tanggal_absen))), ' detik)')
        
        WHEN sk.id_shift = 2 AND a.type = 'in' AND TIME(a.tanggal_absen) <= '14:00:00' THEN 'Tepat Waktu'
        WHEN sk.id_shift = 2 AND a.type = 'out' AND TIME(a.tanggal_absen) >= '20:30:00' THEN 'Pulang Tepat Waktu'
        WHEN sk.id_shift = 2 AND a.type = 'in' AND TIME(a.tanggal_absen) > '14:00:00' THEN CONCAT('Terlambat (', HOUR(TIMEDIFF(TIME(a.tanggal_absen), '14:00:00')), ' jam ', MINUTE(TIMEDIFF(TIME(a.tanggal_absen), '14:00:00')), ' menit ', SECOND(TIMEDIFF(TIME(a.tanggal_absen), '14:00:00')), ' detik)')
        WHEN sk.id_shift = 2 AND a.type = 'out' AND TIME(a.tanggal_absen) < '20:30:00' THEN CONCAT('Pulang Lebih Cepat (', HOUR(TIMEDIFF('20:30:00', TIME(a.tanggal_absen))), ' jam ', MINUTE(TIMEDIFF('20:30:00', TIME(a.tanggal_absen))), ' menit ', SECOND(TIMEDIFF('20:30:00', TIME(a.tanggal_absen))), ' detik)')

        WHEN sk.id_shift = 3 AND a.type = 'in' AND (TIME(a.tanggal_absen) >= '20:30:00' OR TIME(a.tanggal_absen) <= '07:30:00') THEN 'Tepat Waktu'
        WHEN sk.id_shift = 3 AND a.type = 'out' AND (TIME(a.tanggal_absen) >= '07:30:00' AND TIME(a.tanggal_absen) <= '20:30:00') THEN 'Pulang Tepat Waktu'
        WHEN sk.id_shift = 3 AND a.type = 'in' AND TIME(a.tanggal_absen) > '20:30:00' THEN CONCAT('Terlambat (', HOUR(TIMEDIFF(TIME(a.tanggal_absen), '20:30:00')), ' jam ', MINUTE(TIMEDIFF(TIME(a.tanggal_absen), '20:30:00')), ' menit ', SECOND(TIMEDIFF(TIME(a.tanggal_absen), '20:30:00')), ' detik)')
        WHEN sk.id_shift = 3 AND a.type = 'out' AND TIME(a.tanggal_absen) < '07:30:00' THEN CONCAT('Pulang Lebih Cepat (', HOUR(TIMEDIFF('07:30:00', TIME(a.tanggal_absen))), ' jam ', MINUTE(TIMEDIFF('07:30:00', TIME(a.tanggal_absen))), ' menit ', SECOND(TIMEDIFF('07:30:00', TIME(a.tanggal_absen))), ' detik)')
        
        WHEN sk.id_shift = 4 AND a.type = 'in' AND TIME(a.tanggal_absen) <= '07:30:00' THEN 'Tepat Waktu'
        WHEN sk.id_shift = 4 AND a.type = 'out' AND TIME(a.tanggal_absen) >= '16:00:00' THEN 'Pulang Tepat Waktu'
        WHEN sk.id_shift = 4 AND a.type = 'in' AND TIME(a.tanggal_absen) > '07:30:00' THEN CONCAT('Terlambat (', HOUR(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' jam ', MINUTE(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' menit ', SECOND(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' detik)')
        WHEN sk.id_shift = 4 AND a.type = 'out' AND TIME(a.tanggal_absen) < '16:00:00' THEN CONCAT('Pulang Lebih Cepat (', HOUR(TIMEDIFF('16:00:00', TIME(a.tanggal_absen))), ' jam ', MINUTE(TIMEDIFF('16:00:00', TIME(a.tanggal_absen))), ' menit ', SECOND(TIMEDIFF('16:00:00', TIME(a.tanggal_absen))), ' detik)')
        
        WHEN sk.id_shift = 5 AND a.type = 'in' AND TIME(a.tanggal_absen) <= '07:30:00' THEN 'Tepat Waktu'
        WHEN sk.id_shift = 5 AND a.type = 'out' AND TIME(a.tanggal_absen) >= '16:30:00' THEN 'Pulang Tepat Waktu'
        WHEN sk.id_shift = 5 AND a.type = 'in' AND TIME(a.tanggal_absen) > '07:30:00' THEN CONCAT('Terlambat (', HOUR(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' jam ', MINUTE(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' menit ', SECOND(TIMEDIFF(TIME(a.tanggal_absen), '07:30:00')), ' detik)')
        WHEN sk.id_shift = 5 AND a.type = 'out' AND TIME(a.tanggal_absen) < '16:30:00' THEN CONCAT('Pulang Lebih Cepat (', HOUR(TIMEDIFF('16:30:00', TIME(a.tanggal_absen))), ' jam ', MINUTE(TIMEDIFF('16:30:00', TIME(a.tanggal_absen))), ' menit ', SECOND(TIMEDIFF('16:30:00', TIME(a.tanggal_absen))), ' detik)')
    END AS Keterangan,
    sk.id_shift AS Shift
FROM karyawan k
JOIN absen a ON k.kode_karyawan = a.kode_karyawan
LEFT JOIN shift_karyawan sk ON k.kode_karyawan = sk.kode_karyawan AND DATE(sk.tanggal_shift) = DATE(a.tanggal_absen)
WHERE k.role = 'karyawan' 
AND DATE_FORMAT(a.tanggal_absen, '%Y-%m') = '$bulan_ini'
ORDER BY k.kode_karyawan, a.tanggal_absen";
