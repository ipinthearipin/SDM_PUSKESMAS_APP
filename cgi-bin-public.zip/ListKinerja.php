<?php
include 'koneksi.php';
// $hostname = "localhost";
// $user = "id21825478_absenpuskes";
// $password = "SDMkodular123.";
// $database = "id21825478_kodular";
// $port = 3306;

$konekci = mysqli_connect($hostname, $user, $password, $database);

// Query untuk mengambil data
$kodeKaryawan = $_POST['kode_karyawan'];
$data = array();
if(isset($_POST['total'])){
    $sql = "SELECT SUM(lama_kinerja) as 'total_time' FROM kinerja where kode_karyawan = '$kodeKaryawan' AND DATE(tanggal_kinerja) = CURDATE()";
    $result = $konekci->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if($row['total_time'] == null){
            $data["total_time"] = 0;
        }
        else{
            $data["total_time"] = $row['total_time'];
        }
        $data["percentage"] = ($data["total_time"] / 300) * 100;
    }
    else{
        $data["total_time"] = 0;
        $data["percentage"] = 0;
    }
}
else{
    $sql = "SELECT * FROM kinerja where kode_karyawan = '$kodeKaryawan' AND DATE(tanggal_kinerja) = CURDATE()";
    $result = $konekci->query($sql);
    // Menampilkan data
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            array_push($data, $row);
        }
    }
}

echo json_encode($data);

mysqli_close($konekci);
?>
