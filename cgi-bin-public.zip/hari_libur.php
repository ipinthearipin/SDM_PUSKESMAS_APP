<?php
include 'koneksi.php';

$url = "https://api-harilibur.vercel.app/api?year=2025";
$response = file_get_contents($url);
$data = json_decode($response, true);

foreach ($data as $holiday) {
    $tanggal = $holiday['holiday_date'];
    $nama = $holiday['holiday_name'];
    $tipe = 'Nasional';

    $koneksi->query("INSERT IGNORE INTO hari_libur (tanggal, nama_libur, tipe) VALUES ('$tanggal', '$nama', '$tipe')");
}

// Tambahkan weekend (Sabtu & Minggu)
$start = new DateTime("2025-01-01");
$end = new DateTime("2025-12-31");

while ($start <= $end) {
    $hari = $start->format('l'); // Sunday, Monday, etc.
    if ($hari == 'Saturday' || $hari == 'Sunday') {
        $tanggal = $start->format('Y-m-d');
        $nama = $hari;
        $tipe = 'Weekend';

        $koneksi->query("INSERT IGNORE INTO hari_libur (tanggal, nama_libur, tipe) VALUES ('$tanggal', '$nama', '$tipe')");
    }
    $start->modify('+1 day');
}

echo "Import selesai!";
?>
