<?php
include 'koneksi.php';

$sql = "SELECT keterangan FROM absen WHERE keterangan LIKE 'Terlambat%'";
$result = $koneksi->query($sql);

$total_menit = 0;
$total_terlambat = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $keterangan = $row["keterangan"];

        // Ekstrak jam, menit, dan detik dari string
        preg_match('/(\d+) jam (\d+) menit (\d+) detik/', $keterangan, $matches);

        if (!empty($matches)) {
            $jam = intval($matches[1]);
            $menit = intval($matches[2]);
            
            // Konversi jam ke menit lalu tambahkan menit
            $total_menit += ($jam * 60) + $menit;
            $total_terlambat++;
        }
    }
}

// Hitung rata-rata
$rata_rata_keterlambatan = ($total_terlambat > 0) ? round($total_menit / $total_terlambat, 2) : 0;

$data = array("rata_rata_keterlambatan" => $rata_rata_keterlambatan);

// Output JSON
echo json_encode($data);
$koneksi->close();
?>
