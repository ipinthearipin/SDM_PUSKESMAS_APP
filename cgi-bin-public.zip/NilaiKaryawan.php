<?php
include 'koneksi.php';
$kodeKaryawan = $_POST['kode_karyawan'];

// Query untuk mendapatkan total waktu kinerja per tanggal
$sql = "SELECT SUM(lama_kinerja) as waktu, tanggal_kinerja 
        FROM kinerja 
        WHERE kode_karyawan = '$kodeKaryawan' 
        AND DATE_FORMAT(tanggal_kinerja, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m') 
        GROUP BY tanggal_kinerja";

$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    $totalScore = 0;  // Untuk menghitung total waktu kinerja
    $totalDay = 0;    // Untuk menghitung jumlah hari unik
    while($row = $result->fetch_assoc()) {
        $totalScore += $row['waktu'];  // Menambahkan total waktu kinerja per hari
        $totalDay += 1;                // Menambah jumlah hari (unik) setiap kali loop
    }
    // Hitung rata-rata total waktu kerja per hari
    $data['average'] = round($totalScore / $totalDay, 2);  // Dibulatkan ke 2 desimal
} else {
    $data['average'] = 0;  // Jika tidak ada data, set average ke 0
}

echo json_encode($data);
mysqli_close($koneksi);
?>
