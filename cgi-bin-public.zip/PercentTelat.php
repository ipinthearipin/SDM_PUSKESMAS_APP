<?php
include 'koneksi.php';
header("Content-Type: application/json");

// Ambil input kode karyawan
$kodeKaryawan = $_POST['kode_karyawan'];

// Tanggal bulan & tahun sekarang
$bulan_ini = date('m');
$tahun_ini = date('Y');

// Query data telat dan absen berdasarkan bulan & tahun saat ini
$sql = "
    SELECT 
        SUM(CASE WHEN keterangan LIKE 'Terlambat%' THEN 1 ELSE 0 END) AS jumlah_telat,
        COUNT(*) AS jumlah_absen
    FROM absen
    WHERE 
        kode_karyawan = ? 
        AND type = 'in'
        AND MONTH(tanggal_absen) = ? 
        AND YEAR(tanggal_absen) = ?
";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("sii", $kodeKaryawan, $bulan_ini, $tahun_ini);
$stmt->execute();
$result = $stmt->get_result();

$response = [
    "kode_karyawan" => $kodeKaryawan,
    "jumlah_telat" => 0,
    "jumlah_absen" => 0,
    "persentase_telat" => "0.00"
];

if ($row = $result->fetch_assoc()) {
    $telat = intval($row["jumlah_telat"]);
    $absen = intval($row["jumlah_absen"]);
    $persentase = ($absen > 0) ? round(($telat / $absen) * 100, 2) : 0;

    $response["jumlah_telat"] = $telat;
    $response["jumlah_absen"] = $absen;
    $response["persentase_telat"] = number_format($persentase, 2, '.', '');
}

echo json_encode($response);
$stmt->close();
$koneksi->close();
?>
