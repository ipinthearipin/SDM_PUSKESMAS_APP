<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kodeKaryawan'];
$tanggalAbsen = $_POST['tanggalAbsen'];
$type = $_POST['type'];

$dateTime = DateTime::createFromFormat('d-m-Y\TH:i:s', $tanggalAbsen);
$formattedDateTime = $dateTime->format('Y-m-d H:i:s');

$query = "INSERT INTO absen (kode_karyawan, tanggal_absen, type) VALUES (?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "sss", $kodeKaryawan, $formattedDateTime, $type);
$result = mysqli_stmt_execute($stmt);

if ($result) {
    $kodeKaryawan_correct = $kodeKaryawan;
    $data = array(
        "message"=>"Data Berhasil Diupload"
    );
} else {
    $data = array(
        "message"=>"Data Tidak Berhasil Diupload"
    );
}
echo json_encode($data);
?>