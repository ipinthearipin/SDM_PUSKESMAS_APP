<?php
include 'koneksi.php';
date_default_timezone_set("Asia/Jakarta");

if (!isset($_POST['csv_data'])) {
    echo json_encode(["status" => "error", "message" => "Data CSV tidak ditemukan"]);
    exit;
}

$csvData = $_POST['csv_data'];
$rows = explode("\n", trim($csvData));
$inserted = 0;
$skipped = 0;

foreach ($rows as $index => $line) {
    $columns = str_getcsv(trim($line));

    if (count($columns) < 4) {
        $skipped++;
        continue;
    }

    $kode_karyawan = trim($columns[0]);
    $raw_tanggal = trim($columns[1]);
    $nama_jam = trim($columns[2]);
    $lokasi_kerja = trim($columns[3]);

    $dateObj = DateTime::createFromFormat('n/j/Y', $raw_tanggal);
    if (!$dateObj) {
        $skipped++;
        continue;
    }
    $tanggal_shift = $dateObj->format('Y-m-d');

    $stmtJam = $koneksi->prepare("SELECT id_jam_kerja FROM jam_kerja WHERE nama_jam = ?");
    $stmtJam->bind_param("s", $nama_jam);
    $stmtJam->execute();
    $resultJam = $stmtJam->get_result();

    if ($resultJam->num_rows === 0) {
        $skipped++;
        continue;
    }

    $id_jam_kerja = $resultJam->fetch_assoc()['id_jam_kerja'];

    $stmtInsert = $koneksi->prepare("
        INSERT INTO shift_karyawan (kode_karyawan, tanggal_shift, id_jam_kerja, lokasi_kerja)
        VALUES (?, ?, ?, ?)
    ");
    $stmtInsert->bind_param("ssis", $kode_karyawan, $tanggal_shift, $id_jam_kerja, $lokasi_kerja);
    if ($stmtInsert->execute()) {
        $inserted++;
    } else {
        $skipped++;
    }
}

echo json_encode([
    "status" => "success",
    "message" => "Import selesai",
    "inserted" => $inserted,
    "skipped" => $skipped
]);

$koneksi->close();
?>
