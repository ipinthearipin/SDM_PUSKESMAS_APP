<?php
include 'koneksi.php';

// Query to count the number of employees with the role 'karyawan' and 'hrd'
$sql = "
    SELECT role, COUNT(kode_karyawan) as jumlah FROM karyawan WHERE role IN ('karyawan', 'hrd') GROUP BY role
";
$result = $koneksi->query($sql);

$data = array();
$total_karyawan = 0;

// Calculate total number of employees
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $total_karyawan += intval($row['jumlah']);
        $data[$row['role']] = intval($row['jumlah']);
    }
}

// Calculate percentages
if ($total_karyawan > 0) {
    foreach ($data as $role => $jumlah) {
        $data[$role] = round(($jumlah / $total_karyawan) * 100, 2); // Calculate percentage and round to 2 decimal places
    }
} else {
    $data['karyawan'] = 0;
    $data['hrd'] = 0;
}

// Output the data in JSON format
echo json_encode($data);
mysqli_close($koneksi);
?>
