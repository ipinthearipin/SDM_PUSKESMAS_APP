<?php
// URL API Kalender Indonesia (2025)
$url = "https://kalenderindonesia.com/api/2cbd2cf3ecc0955a/libur/masehi/2025";

// Ambil data dari API
$response = file_get_contents($url);
$data = json_decode($response, true);

// Periksa apakah berhasil ambil data
if ($data && isset($data["success"]) && $data["success"] === true) {

    // Koneksi ke database (ganti sesuai kebutuhan)
    $hostname = "localhost";
    $database = "sdmq3294_apksdm";
    $user = "sdmq3294";
    $password = "zgfignZ73c5P53";

   
    try {
        $pdo = new PDO("mysql:host=$hostname;dbname=$databse", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Siapkan query insert
        $stmt = $pdo->prepare("INSERT INTO hari_libur (tanggal, nama_libur) VALUES (?, ?)");

        // Loop data libur
        foreach ($data["data"]["holidays"] as $libur) {
            $tanggal = $libur["masehi"];
            $nama_libur = "Libur Nasional"; // Bisa diganti kalau API punya nama libur spesifik

            // Eksekusi insert
            $stmt->execute([$tanggal, $nama_libur]);
        }

        echo "Data hari libur berhasil disimpan ke database.";
    } catch (PDOException $e) {
        echo "Koneksi atau query gagal: " . $e->getMessage();
    }
} else {
    echo "Gagal mengambil data dari API.";
}
?>
