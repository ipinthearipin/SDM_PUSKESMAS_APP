<?php
include 'koneksi.php';

$kodeKaryawan = isset($_GET['kode_karyawan']) ? $_GET['kode_karyawan'] : '';
$bulan = isset($_GET['bulan']) ? (int)$_GET['bulan'] : 0;
$tahun = isset($_GET['tahun']) ? (int)$_GET['tahun'] : 0;

if (empty($kodeKaryawan) || $bulan === 0 || $tahun === 0) {
    http_response_code(400);
    echo "Parameter kode_karyawan, bulan, dan tahun wajib diisi";
    exit;
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=absen_karyawan_' . $kodeKaryawan . "_{$bulan}_{$tahun}.csv");

$output = fopen('php://output', 'w');
fputcsv($output, ['Kode Karyawan', 'Nama Karyawan', 'Tanggal Absen', 'Type', 'Lokasi Kerja', 'Keterangan', 'Jam Kerja']);

$query = "
    SELECT 
        a.kode_karyawan, 
        k.nama_karyawan, 
        a.tanggal_absen, 
        a.type, 
        a.lokasi_kerja, 
        a.keterangan,
        jk.nama_jam AS jam_kerja
    FROM absen a
    JOIN karyawan k ON a.kode_karyawan = k.kode_karyawan
    LEFT JOIN shift_karyawan sk ON a.kode_karyawan = sk.kode_karyawan AND DATE(a.tanggal_absen) = sk.tanggal_shift
    LEFT JOIN jam_kerja jk ON sk.id_jam_kerja = jk.id_jam_kerja
    WHERE a.kode_karyawan = ?
      AND MONTH(a.tanggal_absen) = ?
      AND YEAR(a.tanggal_absen) = ?
    ORDER BY a.tanggal_absen ASC
";

$stmt = $koneksi->prepare($query);
$stmt->bind_param("sii", $kodeKaryawan, $bulan, $tahun);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
?>
