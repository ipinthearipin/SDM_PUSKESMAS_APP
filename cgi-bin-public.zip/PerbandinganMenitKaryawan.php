<?php
include 'koneksi.php';
header('Content-Type: application/json');

$response = [];

// Visualisasi Persentase Menit Telat dan Pulang Cepat
$sql_menit = "
    SELECT 
        SUM(CASE WHEN keterangan LIKE 'Terlambat%' THEN 
            TIME_TO_SEC(STR_TO_DATE(SUBSTRING_INDEX(SUBSTRING_INDEX(keterangan, '(', -1), ')', 1), '%H jam %i menit %s detik')) / 60 
        ELSE 0 END) AS total_terlambat,

        SUM(CASE WHEN keterangan LIKE 'Pulang Lebih Cepat%' THEN 
            TIME_TO_SEC(STR_TO_DATE(SUBSTRING_INDEX(SUBSTRING_INDEX(keterangan, '(', -1), ')', 1), '%H jam %i menit %s detik')) / 60 
        ELSE 0 END) AS total_cepat
    FROM absensi
";

$result_menit = $koneksi->query($sql_menit);
if ($result_menit && $row = $result_menit->fetch_assoc()) {
    $total_menit = $row['total_terlambat'] + $row['total_cepat'];
    if ($total_menit > 0) {
        $response = [
            'Terlambat' => round(($row['total_terlambat'] / $total_menit) * 100, 2),
            'Pulang Lebih Cepat' => round(($row['total_cepat'] / $total_menit) * 100, 2)
        ];
    } else {
        $response = [
            'Terlambat' => 0,
            'Pulang Lebih Cepat' => 0
        ];
    }
}

// Output JSON
echo json_encode($response);

mysqli_close($koneksi);
?>