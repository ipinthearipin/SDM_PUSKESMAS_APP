<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kode_karyawan'];
$data = array();

$waktuSekarang = date("Y-m-d H:i:s");

$sqlShift = "SELECT sk.tanggal_shift, jk.jam_masuk, jk.jam_pulang 
             FROM shift_karyawan sk 
             JOIN jam_kerja jk ON jk.id_jam_kerja = sk.id_jam_kerja
             WHERE sk.kode_karyawan = ? 
             AND sk.tanggal_shift >= CURDATE()
             ORDER BY sk.tanggal_shift ASC, jk.jam_masuk ASC";

$stmtShift = $koneksi->prepare($sqlShift);
$stmtShift->bind_param("s", $kodeKaryawan);
$stmtShift->execute();
$resultShift = $stmtShift->get_result();

$shiftList = [];

while ($rowShift = $resultShift->fetch_assoc()) {
    $shiftList[] = [
        "tanggal_shift" => $rowShift["tanggal_shift"],
        "jam_masuk" => $rowShift["jam_masuk"],
        "jam_pulang" => $rowShift["jam_pulang"]
    ];
}

$data["button"] = "Disabled";
$data["message"] = "Tidak ada shift terdaftar.";
$data["radio_button"] = [
    "jadwal_kerja" => false,
    "check_in" => false,
    "check_out" => false
];

if (!empty($shiftList)) {
    foreach ($shiftList as $shift) {
        $shiftDate = $shift["tanggal_shift"];
        $jamMasuk = $shift["jam_masuk"];
        $jamPulang = $shift["jam_pulang"];

        $shiftStart = $shiftDate . " " . $jamMasuk;
        $shiftEnd = $shiftDate . " " . $jamPulang;
        $batasCheckIn = date("Y-m-d H:i:s", strtotime($shiftStart . " -30 minutes"));
        $batasCheckOut = date("Y-m-d H:i:s", strtotime($shiftEnd . " +30 minutes"));

        $sqlAbsen = "SELECT * FROM absen 
                     WHERE kode_karyawan = ? 
                     AND DATE(tanggal_absen) = ?
                     ORDER BY tanggal_absen ASC";
        $stmtAbsen = $koneksi->prepare($sqlAbsen);
        $stmtAbsen->bind_param("ss", $kodeKaryawan, $shiftDate);
        $stmtAbsen->execute();
        $resultAbsen = $stmtAbsen->get_result();

        $sudahCheckIn = false;
        $sudahCheckOut = false;

        while ($rowAbsen = $resultAbsen->fetch_assoc()) {
            if ($rowAbsen["type"] == "in") {
                $sudahCheckIn = true;
                $data["in"] = $rowAbsen["tanggal_absen"];
            }
            if ($rowAbsen["type"] == "out") {
                $sudahCheckOut = true;
                $data["out"] = $rowAbsen["tanggal_absen"];
            }
        }

        // Tentukan tombol yang aktif
        if (!$sudahCheckIn && $waktuSekarang >= $batasCheckIn) {
            $data["button"] = "Check In";
            $data["message"] = "Silakan Check In untuk shift pada " . $shiftStart;
            $data["radio_button"]["jadwal_kerja"] = true;
            $data["radio_button"]["check_in"] = true;
            break;
        } elseif ($sudahCheckIn && !$sudahCheckOut) {
            if ($waktuSekarang <= $batasCheckOut) {
                $data["button"] = "Check Out";
                $data["message"] = "Silakan Check Out sebelum " . $batasCheckOut;
                $data["radio_button"]["jadwal_kerja"] = true;
                $data["radio_button"]["check_out"] = true;
            } else {
                $data["button"] = "Disabled";
                $data["message"] = "Melewati batas waktu Check Out (" . $batasCheckOut . ")";
            }
            break;
        }
    }

    if (!isset($data["button"]) || $data["button"] == "Disabled") {
        $data["button"] = "Disabled";
        $data["message"] = "Absensi untuk semua shift hari ini telah selesai atau melewati batas waktu.";
    }
}

echo json_encode($data);
$koneksi->close();
?>
