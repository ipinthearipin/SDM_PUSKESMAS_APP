<?php
include 'koneksi.php';
header("Content-Type: application/json");

$konekci = mysqli_connect($hostname, $user, $password, $database);

$kodeKaryawan = $_POST['kode_karyawan'];
$sql = "SELECT * FROM karyawan WHERE kode_karyawan = '$kodeKaryawan'";
$result = $konekci->query($sql);

$data = array();
if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
} else {
    $data = ["error" => "Tidak ada data"];
}

echo json_encode($data);
mysqli_close($konekci);
?>