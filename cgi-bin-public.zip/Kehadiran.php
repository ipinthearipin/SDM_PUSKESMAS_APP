<?php
include 'koneksi.php';

// Query untuk menghitung jumlah karyawan yang hadir
$sql = "SELECT COUNT(DISTINCT kode_karyawan) as hadir FROM absen WHERE DATE(tanggal_absen) = CURDATE() AND type = 'in'";
$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data['hadir'] = $row['hadir'];
} else {
    $data['hadir'] = 0; // Jika tidak ada yang hadir, set nilai default
}

// Query untuk menghitung jumlah karyawan yang tidak hadir
$sql = "SELECT COUNT(kode_karyawan) as tidak_hadir FROM karyawan WHERE role = 'karyawan' AND kode_karyawan NOT IN (
    SELECT DISTINCT kode_karyawan FROM absen WHERE DATE(tanggal_absen) = CURDATE() AND type = 'in'
)";
$result = $koneksi->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data['tidak_hadir'] = $row['tidak_hadir'];
} else {
    $data['tidak_hadir'] = 0; // Jika semua hadir, set nilai default
}

echo json_encode($data);
mysqli_close($koneksi);
?>
