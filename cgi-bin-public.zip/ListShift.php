<?php
include 'koneksi.php';

$kode_karyawan = isset($_GET['kode_karyawan']) ? $_GET['kode_karyawan'] : null;

if ($kode_karyawan) {
    // Gunakan prepared statement
    $stmt = $koneksi->prepare("SELECT jk.*, k.kode_karyawan FROM jam_kerja jk 
                               JOIN karyawan k ON jk.id_tipe = k.id_tipe 
                               WHERE k.kode_karyawan = ?");
    $stmt->bind_param("s", $kode_karyawan); 
    $stmt->execute();
    $result = $stmt->get_result();

    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode($data);

    $stmt->close();
} else {
    echo json_encode(array("error" => "Parameter kode_karyawan tidak ditemukan."));
}

$koneksi->close();
?>
