<?php
include 'koneksi.php';

// Pastikan koneksi ke database berhasil
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Set header agar file diunduh sebagai CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=absen_export.csv');

// Buka output sebagai file CSV
$output = fopen('php://output', 'w');

// Tulis header kolom
fputcsv($output, array('ID', 'Kode Karyawan', 'Tanggal Absen', 'Type', 'Lokasi Kerja', 'Keterangan', 'ID Shift'));

// Query untuk mengambil data
$query = "
    SELECT a.id_absen, a.kode_karyawan, a.tanggal_absen, a.type, a.lokasi_kerja, a.keterangan, sk.id_shift 
    FROM absen a
    LEFT JOIN shift_karyawan sk ON a.kode_karyawan = sk.kode_karyawan
    ORDER BY a.tanggal_absen DESC";

$result = mysqli_query($koneksi, $query);

// Cek apakah query berhasil dijalankan
if (!$result) {
    die("Error query: " . mysqli_error($koneksi));
}

// Tulis data hasil query ke file CSV
while ($row = mysqli_fetch_assoc($result)) {
    // Pastikan data tidak bermasalah
    fputcsv($output, array_map("utf8_encode", $row));
}

// Tutup file CSV
fclose($output);
?>
