<?php
include 'koneksi.php';

// Ambil data dari POST
$tanggal = $_POST['tanggal'];       // format: YYYY-MM-DD
$nama_libur = $_POST['nama_libur'];
$tipe = $_POST['tipe'];

// Validasi sederhana
if (empty($tanggal) || empty($nama_libur) || empty($tipe)) {
    echo json_encode(["message" => "Data tidak lengkap"]);
    exit;
}

// Insert data (tanpa cek duplikat tanggal)
$queryInsert = "INSERT INTO hari_libur (tanggal, nama_libur, tipe) VALUES (?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $queryInsert);
mysqli_stmt_bind_param($stmt, "sss", $tanggal, $nama_libur, $tipe);
$result = mysqli_stmt_execute($stmt);

if ($result) {
    echo json_encode(["message" => "Hari libur berhasil ditambahkan"]);
} else {
    echo json_encode(["message" => "Gagal menambahkan hari libur: " . mysqli_error($koneksi)]);
}

mysqli_stmt_close($stmt);
?>
