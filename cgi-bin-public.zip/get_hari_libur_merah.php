<?php
header('Content-Type: application/json');
include 'koneksi.php';

$data = [];

// Ambil semua tanggal merah dari tabel hari_libur
$query = "SELECT tanggal FROM hari_libur";
$result = $koneksi->query($query);

while ($row = $result->fetch_assoc()) {
    if (!in_array($row['tanggal'], $data)) {
        $data[] = $row['tanggal'];
    }
}

// Output JSON seperti: { "libur": ["2025-01-01", "2025-02-10"] }
echo json_encode(['libur' => $data]);
?>
