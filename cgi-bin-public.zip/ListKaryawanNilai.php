<?php
include 'koneksi.php';

// Mendapatkan bulan dan tahun saat ini
$currentMonth = date('m');
$currentYear = date('Y');

// Query untuk mengambil nilai bulan berjalan dan perhitungan score dengan satu angka di belakang koma
$sql = "
    SELECT k.*, p.nilai, p.tanggal_input, ROUND(p3.score, 1) AS score
    FROM karyawan k
    LEFT JOIN (
        -- Subquery untuk nilai terbaru bulan berjalan
        SELECT p1.kode_karyawan, p1.nilai, p1.tanggal_input
        FROM penilaian_kinerja_karyawan p1
        WHERE YEAR(p1.tanggal_input) = '$currentYear' 
        AND MONTH(p1.tanggal_input) = '$currentMonth'
        AND p1.tanggal_input = (
            SELECT MAX(tanggal_input)
            FROM penilaian_kinerja_karyawan p2
            WHERE p1.kode_karyawan = p2.kode_karyawan
            AND YEAR(p2.tanggal_input) = '$currentYear'
            AND MONTH(p2.tanggal_input) = '$currentMonth'
        )
    ) p ON k.kode_karyawan = p.kode_karyawan
    LEFT JOIN (
        -- Subquery untuk perhitungan score rata-rata berdasarkan nilai terbaru per bulan
        SELECT p1.kode_karyawan, ROUND(AVG(p1.nilai), 1) AS score
        FROM penilaian_kinerja_karyawan p1
        INNER JOIN (
            SELECT kode_karyawan, MAX(tanggal_input) AS max_tanggal
            FROM penilaian_kinerja_karyawan
            GROUP BY kode_karyawan, YEAR(tanggal_input), MONTH(tanggal_input)
        ) p2 ON p1.kode_karyawan = p2.kode_karyawan AND p1.tanggal_input = p2.max_tanggal
        GROUP BY p1.kode_karyawan
    ) p3 ON k.kode_karyawan = p3.kode_karyawan
    WHERE k.role = 'karyawan'
    ORDER BY p.tanggal_input DESC
";

$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Jika nilai tidak ditemukan, set nilai sebagai null
        if (is_null($row['nilai'])) {
            $row['nilai'] = null;
        }
        array_push($data, $row);
    }
}

echo json_encode($data);
mysqli_close($koneksi);
?>
