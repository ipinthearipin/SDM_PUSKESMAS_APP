<?php

$hostname = "localhost";
$user = "id21825478_absenpuskes";
$password = "SDMkodular123.";
$database = "id21825478_kodular";
$port = 3306;

$konekci = mysqli_connect($hostname, $user, $password, $database);

// Check connection
if (!$konekci) {
    die("Connection failed: " . mysqli_connect_error());
}

$kode_karyawan = $_POST['kode_karyawan'];
$nama_karyawan = $_POST['nama_karyawan'];
$email_karyawan = $_POST['email_karyawan'];
$password_karyawan = $_POST['password_karyawan'];
$telepon_karyawan = $_POST['telepon_karyawan'];
$tanggal_lahir_karyawan = $_POST['tanggal_lahir_karyawan'];
$role = $_POST['role'];

$tanggal_lahir_karyawan = date("Y-m-d", strtotime($tanggal_lahir_karyawan));

$query = "INSERT INTO karyawan (kode_karyawan, nama_karyawan, email_karyawan, password_karyawan, telepon_karyawan, tanggal_lahir_karyawan, role) VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = mysqli_prepare($konekci, $query);

if (!$stmt) {
    die("Query preparation failed: " . mysqli_error($konekci));
}

mysqli_stmt_bind_param($stmt, "sssssss", $kode_karyawan, $nama_karyawan, $email_karyawan, $password_karyawan, $telepon_karyawan, $date_lahir, $role);

$result = mysqli_stmt_execute($stmt);

$data = array();

if ($result) {
    $data = array(
        "message" => "Data Berhasil Diupload"
    );
} else {
    $data = array(
        "message" => "Data Tidak Berhasil Diupload"
    );
}

echo json_encode($data);

mysqli_close($konekci);
?>
