<?php
include 'koneksi.php';
header("Content-Type: application/json");

$sql = "SELECT * FROM tipe_pegawai";

$result = $koneksi->query($sql);

$data = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    $data = ["error" => "Tidak ada data tipe pegawai."];
}

echo json_encode($data);
mysqli_close($koneksi);
?>
