<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kode_karyawan'];
$tanggalMulai = $_POST['tanggal_mulai'];
$tanggalSelesai = $_POST['tanggal_selesai'];
$response = array();


// Ambil tanggal_mulai dan tanggal_selesai dari form_ketidakhadiran
$sqlTanggal = "SELECT tanggal_mulai, tanggal_selesai FROM form_ketidakhadiran 
               WHERE kode_karyawan = ? ORDER BY idform_ketidakhadiran DESC LIMIT 1";
$stmtTanggal = $koneksi->prepare($sqlTanggal);
$stmtTanggal->bind_param("s", $kodeKaryawan);
$stmtTanggal->execute();
$resultTanggal = $stmtTanggal->get_result();
$rowTanggal = $resultTanggal->fetch_assoc();
$stmtTanggal->close();

if (!$rowTanggal) {
    echo json_encode(["error" => "Data tidak ditemukan di form_ketidakhadiran"]);
    exit;
}

$tanggalMulai = $rowTanggal['tanggal_mulai'];
$tanggalSelesai = $rowTanggal['tanggal_selesai'];

// Query untuk mengecek apakah ada shift di antara tanggal_mulai dan tanggal_selesai
$sqlShift = "SELECT tanggal_shift FROM shift_karyawan 
             WHERE kode_karyawan = ? 
             AND tanggal_shift BETWEEN ? AND ?";
$stmtShift = $koneksi->prepare($sqlShift);
$stmtShift->bind_param("sss", $kodeKaryawan, $tanggalMulai, $tanggalSelesai);
$stmtShift->execute();
$resultShift = $stmtShift->get_result();

$shiftBertabrakan = [];
while ($row = $resultShift->fetch_assoc()) {
    $shiftBertabrakan[] = $row['tanggal_shift'];
}
$stmtShift->close();

// Query untuk mengecek apakah ada absen di antara tanggal_mulai dan tanggal_selesai
$sqlAbsen = "SELECT tanggal_absen FROM absen 
             WHERE kode_karyawan = ? 
             AND tanggal_absen BETWEEN ? AND ?";
$stmtAbsen = $koneksi->prepare($sqlAbsen);
$stmtAbsen->bind_param("sss", $kodeKaryawan, $tanggalMulai, $tanggalSelesai);
$stmtAbsen->execute();
$resultAbsen = $stmtAbsen->get_result();

$hadirBertabrakan = [];
while ($row = $resultAbsen->fetch_assoc()) {
    $hadirBertabrakan[] = $row['tanggal_absen'];
}
$stmtAbsen->close();

// Cek apakah ada bentrok tanggal
if (!empty($shiftBertabrakan) || !empty($hadirBertabrakan)) {
    $response['button'] = 'Disabled';
    $pesan = [];

    if (!empty($shiftBertabrakan)) {
        $pesan[] = 'Anda memiliki shift pada tanggal: ' . implode(", ", $shiftBertabrakan);
    }
    if (!empty($hadirBertabrakan)) {
        $pesan[] = 'Anda telah hadir pada tanggal: ' . implode(", ", $hadirBertabrakan);
    }

    $response['message'] = implode('. ', $pesan) . '. Harap pilih tanggal lain.';
} else {
    $response['button'] = 'Enabled';
    $response['message'] = 'Silakan lanjutkan pengisian form ketidakhadiran.';
}

// Output JSON
echo json_encode($response);
$koneksi->close();
?>
