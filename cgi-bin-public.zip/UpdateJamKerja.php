<?php
include 'koneksi.php';
header("Content-Type: application/json");

// Validasi koneksi
if (!$koneksi) {
    echo json_encode(["status" => "error", "message" => "Koneksi database gagal"]);
    exit();
}

// Ambil data dari POST
$id_jam_kerja = $_POST['id_jam_kerja'] ?? '';
$nama_jam     = $_POST['nama_jam'] ?? '';
$nama_tipe    = $_POST['nama_tipe'] ?? '';
$jam_masuk    = $_POST['jam_masuk'] ?? '';
$jam_pulang   = $_POST['jam_pulang'] ?? '';
$is_aktif     = $_POST['is_aktif'] ?? '';

// Validasi minimal data penting
if (empty($id_jam_kerja) || empty($nama_jam) || empty($nama_tipe) || empty($jam_masuk) || empty($jam_pulang)) {
    echo json_encode(["status" => "error", "message" => "Data tidak lengkap"]);
    exit();
}

// Pastikan jam dalam format hh:mm:ss
if (strlen($jam_masuk) == 5) $jam_masuk .= ":00";
if (strlen($jam_pulang) == 5) $jam_pulang .= ":00";

// Ambil id_tipe dari nama_tipe
$queryTipe = "SELECT id_tipe FROM tipe_pegawai WHERE nama_tipe = ?";
$stmtTipe = $koneksi->prepare($queryTipe);
$stmtTipe->bind_param("s", $nama_tipe);
$stmtTipe->execute();
$resultTipe = $stmtTipe->get_result();
$rowTipe = $resultTipe->fetch_assoc();

if (!$rowTipe) {
    echo json_encode(["status" => "error", "message" => "Tipe pegawai tidak ditemukan"]);
    exit();
}
$id_tipe = $rowTipe['id_tipe'];

// Update jam kerja
$query = "UPDATE jam_kerja 
          SET nama_jam = ?, id_tipe = ?, jam_masuk = ?, jam_pulang = ?, is_aktif = ?
          WHERE id_jam_kerja = ?";
$stmt = $koneksi->prepare($query);
$stmt->bind_param("sissii", $nama_jam, $id_tipe, $jam_masuk, $jam_pulang, $is_aktif, $id_jam_kerja);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Jam kerja berhasil diupdate"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal mengupdate data", "sql_error" => $stmt->error]);
}

$stmt->close();
$koneksi->close();
?>
