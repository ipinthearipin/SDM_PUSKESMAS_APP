<?php
include 'koneksi.php';

$name = $_POST['name'];
$image = $_POST['image'];
$date = $_POST['date'];
$duration = $_POST['durasi'];
$coordinator = $_POST['penyelenggara'];
$place = $_POST['tempat'];
$kodeKaryawan = $_POST['kode_karyawan'];
$jenisDiklat = $_POST['jenis_diklat'];

$date = date("Y-m-d", strtotime($date));

$query = "INSERT INTO diklat (nama_diklat, tanggal_diklat, penyelenggara, tempat, durasi, jenis_diklat, nama_gambar_diklat, kode_karyawan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "ssssisss",$name, $date, $coordinator, $place, $duration, $jenisDiklat, $image, $kodeKaryawan);
$result = mysqli_stmt_execute($stmt);

if ($result) {
    $data = array(
        "message"=>"Data Berhasil Diupload"
    );
} else {
    $data = array(
        "message"=>"Data Tidak Berhasil Diupload"
    );
}
echo json_encode($data);

?>