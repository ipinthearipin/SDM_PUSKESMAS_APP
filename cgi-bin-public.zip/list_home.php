<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kodeKaryawan'];
$sql = "SELECT * FROM kinerja where kode_karyawan = '$kodeKaryawan'";
$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // echo "<br>";
        // print_r($row);
        $row["kinerja"] = $row["lama_kinerja"];
        array_push($data, $row);
    }
} else {
    echo "Tidak ada data.";
}
echo json_encode($data);
mysqli_close($koneksi);

?>