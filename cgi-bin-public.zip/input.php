<?php
include "koneksi.php";
$sql	=mysqli_query($koneksi,"Select max(id) as KodeMAX From ketidakhadiran");
$data	=mysqli_fetch_array($sql);
$kode 	=$data['KodeMAX'];
$urutan	=(int) substr($kode,2,7);
$urutan++;
$huruf	="KT-";
$kode 	=$huruf.sprintf("%03s",$urutan);
$jenis	=$_GET['jenis'];
$tgl		=$_GET['tgl'];
$ket		=$_GET['ket'];
$gambar		=$_GET['gambar'];

$query=mysqli_query($koneksi,"Select * From ketidakhadiran where jenis='$jenis'");
$cek=mysqli_num_rows($query);

if ($cek>0) {
	echo "Data barang sudah ditambahkan sebelumnya!";
}else{
	$insert="INSERT INTO ketidakhadiran values ('$kode','$jenis','$tgl','$ket','$gambar')";
	if (mysqli_query($koneksi,$insert)) {
		echo "Data berhasil ditambahkan!";
	}else{
		echo "Data gagal ditambahkan!";
	}
}

?>