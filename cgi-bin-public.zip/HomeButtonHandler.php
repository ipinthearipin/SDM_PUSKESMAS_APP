<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kode_karyawan'];
$data = array();

// Ambil shift yang akan datang untuk karyawan
$sqlShift = "SELECT sk.tanggal_shift, jk.jam_masuk, jk.jam_pulang 
             FROM shift_karyawan sk
             JOIN jam_kerja jk ON jk.id_jam_kerja = sk.id_jam_kerja
             WHERE sk.kode_karyawan = ?
             AND sk.tanggal_shift >= CURDATE()
             ORDER BY sk.tanggal_shift ASC, jk.jam_masuk ASC";

$stmtShift = $koneksi->prepare($sqlShift);
$stmtShift->bind_param("s", $kodeKaryawan);
$stmtShift->execute();
$resultShift = $stmtShift->get_result();

$shiftList = [];
while ($rowShift = $resultShift->fetch_assoc()) {
    $shiftList[] = [
        "tanggal_shift" => $rowShift["tanggal_shift"],
        "jam_masuk" => $rowShift["jam_masuk"],
        "jam_pulang" => $rowShift["jam_pulang"]
    ];
}

$waktuSekarang = date("Y-m-d H:i:s");

if (!empty($shiftList)) {
    foreach ($shiftList as $shift) {
        $shiftDate = $shift["tanggal_shift"];
        $jamMasuk = $shift["jam_masuk"];
        $jamPulang = $shift["jam_pulang"];

        $shiftStart = $shiftDate . " " . $jamMasuk;
        $shiftEnd = $shiftDate . " " . $jamPulang;

        $batasCheckIn = date("Y-m-d H:i:s", strtotime($shiftStart . " -30 minutes"));
        $batasCheckOut = date("Y-m-d H:i:s", strtotime($shiftEnd . " +30 minutes"));

        $sqlAbsen = "SELECT * FROM absen 
                     WHERE kode_karyawan = ?
                     AND DATE(tanggal_absen) = ?
                     ORDER BY tanggal_absen ASC";
        $stmtAbsen = $koneksi->prepare($sqlAbsen);
        $stmtAbsen->bind_param("ss", $kodeKaryawan, $shiftDate);
        $stmtAbsen->execute();
        $resultAbsen = $stmtAbsen->get_result();

        $sudahCheckIn = false;
        $sudahCheckOut = false;

        while ($rowAbsen = $resultAbsen->fetch_assoc()) {
            if ($rowAbsen["type"] == "in" && $rowAbsen["tanggal_absen"] >= $shiftStart) {
                $sudahCheckIn = true;
                $data["in"] = $rowAbsen["tanggal_absen"];
            }
            if ($rowAbsen["type"] == "out" && $rowAbsen["tanggal_absen"] >= $shiftStart) {
                $sudahCheckOut = true;
                $data["out"] = $rowAbsen["tanggal_absen"];
            }
        }

        if (!$sudahCheckIn && $waktuSekarang >= $batasCheckIn) {
            $data["shift_start"] = $shiftStart;
            $data["batas_check_in"] = $batasCheckIn;
            $data["waktu_sekarang"] = $waktuSekarang;
            $data["button"] = "Check In";
            $data["message"] = "Silakan Check In untuk shift pada " . $shiftStart;
            break;
        } elseif ($sudahCheckIn && !$sudahCheckOut && $waktuSekarang <= $batasCheckOut) {
            $data["shift_start"] = $shiftStart;
            $data["batas_check_in"] = $batasCheckIn;
            $data["waktu_sekarang"] = $waktuSekarang;
            $data["button"] = "Check Out";
            $data["message"] = "Silakan Check Out untuk shift pada " . $shiftStart;
            break;
        }
    }

    if (!isset($data["button"])) {
        $data["shift_start"] = "";
        $data["batas_check_in"] = "";
        $data["waktu_sekarang"] = $waktuSekarang;
        $data["button"] = "Disabled";
        $data["message"] = "Absensi untuk semua shift hari ini telah selesai atau sudah melebihi batas waktu.";
    }
} else {
    $data["shift_start"] = "";
    $data["batas_check_in"] = "";
    $data["waktu_sekarang"] = $waktuSekarang;
    $data["button"] = "Disabled";
    $data["message"] = "Tidak ada shift terdaftar.";
}

echo json_encode($data);
$koneksi->close();
?>
