<?php
include 'koneksi.php';

// Ganti nilai $kode_karyawan dengan kode karyawan yang ingin Anda periksa
$kode_karyawan = 'kode_karyawan_yang_dipilih';
$status = 'hadir'; // Ubah status sesuai kebutuhan Anda

if ($status == 'hadir') {
    $sql = "SELECT * FROM karyawan k JOIN absen a ON k.kode_karyawan = a.kode_karyawan WHERE k.kode_karyawan = '$kode_karyawan' AND MONTH(a.tanggal_absen) = MONTH(CURRENT_DATE())";
}

$result = $koneksi->query($sql);

$data = array();
if ($result) {
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            array_push($data, $row);
        }
    } else {
        echo "Tidak ada data.";
    }
} else {
    echo "Terjadi kesalahan dalam eksekusi kueri: " . $koneksi->error;
}

echo json_encode($data);
mysqli_close($koneksi);
?>
