<?php
include 'koneksi.php';

$action = $_POST['action']; // "update" atau "delete"
$id_hari_libur = $_POST['id_hari_libur'];

if ($action == "update") {
    $tanggal = $_POST['tanggal'];
    $nama_libur = $_POST['nama_libur'];
    $tipe = $_POST['tipe'];

    if (empty($tanggal) || empty($nama_libur) || empty($tipe)) {
        echo json_encode(["message" => "Data tidak lengkap untuk update"]);
        exit;
    }

    $query = "UPDATE hari_libur SET tanggal = ?, nama_libur = ?, tipe = ? WHERE id_hari_libur = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "sssi", $tanggal, $nama_libur, $tipe, $id_hari_libur);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo json_encode(["message" => "Berhasil update data libur"]);
    } else {
        echo json_encode(["message" => "Gagal update: " . mysqli_error($koneksi)]);
    }
    mysqli_stmt_close($stmt);
}
elseif ($action == "delete") {
    $query = "DELETE FROM hari_libur WHERE id_hari_libur = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "i", $id_hari_libur);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo json_encode(["message" => "Berhasil hapus data libur"]);
    } else {
        echo json_encode(["message" => "Gagal hapus: " . mysqli_error($koneksi)]);
    }
    mysqli_stmt_close($stmt);
}
else {
    echo json_encode(["message" => "Aksi tidak valid"]);
}
?>
