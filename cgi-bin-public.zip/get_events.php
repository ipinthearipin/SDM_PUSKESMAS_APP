<?php
header("Content-type: application/json");

$hostname = "localhost";
$user = "sdmq3294";
$password = "zgfignZ73c5P53";
$database = "sdmq3294_apksdm";

$koneksi = mysqli_connect($hostname, $user, $password, $database);

if (!$koneksi) {
    die(json_encode(["error" => "Koneksi database gagal: " . mysqli_connect_error()]));
}

if (!isset($_GET['date'])) {
    die(json_encode(["error" => "tanggal salah"]));
}

$date = $_GET['date'];
$dayOfWeek = date('N', strtotime($date));

$sql = "SELECT nama_liburan FROM liburan WHERE tanggal_liburan = ?";
$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "s", $date);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$response = [
    "date" => $date,
    "is_holiday" => false,
    "holiday_name" => null,
    "is_weekend" => false
];

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $response["is_holiday"] = true;
    $response["holiday_name"] = $row['nama_liburan'];
}

if ($dayOfWeek == 6 || $dayOfWeek == 7) {
    $response["is_weekend"] = true;
}

echo json_encode($response);

mysqli_close($koneksi);
?>