<?php
include 'koneksi.php';

// Query untuk menghitung jumlah kehadiran berdasarkan keterangan
$sql = "
    SELECT 
        SUM(CASE WHEN keterangan LIKE 'Tepat Waktu%' THEN 1 ELSE 0 END) AS tepat_waktu,
        SUM(CASE WHEN keterangan LIKE 'Terlambat%' THEN 1 ELSE 0 END) AS terlambat
    FROM absen
";
$result = $koneksi->query($sql);

$data = array(
    "tepat_waktu" => 0,
    "terlambat" => 0
);

$total_kehadiran = 0;

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data["tepat_waktu"] = intval($row["tepat_waktu"]);
    $data["terlambat"] = intval($row["terlambat"]);
    $total_kehadiran = $data["tepat_waktu"] + $data["terlambat"];
}

// Menghitung persentase dengan format yang lebih presisi
if ($total_kehadiran > 0) {
    $data["tepat_waktu"] = round(($data["tepat_waktu"] / $total_kehadiran) * 100, 2);
    $data["terlambat"] = round(($data["terlambat"] / $total_kehadiran) * 100, 2);
    
    // Konversi ke string agar JSON tidak menampilkan floating-point panjang
    $data["tepat_waktu"] = number_format($data["tepat_waktu"], 2, '.', '');
    $data["terlambat"] = number_format($data["terlambat"], 2, '.', '');
}

// Output JSON
echo json_encode($data);
$koneksi->close();
?>
