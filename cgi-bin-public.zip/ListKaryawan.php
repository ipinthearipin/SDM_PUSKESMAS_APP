<?php
include 'koneksi.php';

$sql = "SELECT 
            k.kode_karyawan,
            k.nama_karyawan,
            k.email_karyawan,
            k.telepon_karyawan,
            k.tanggal_lahir_karyawan,
            k.role,
            k.gambar_karyawan,
            tp.nama_tipe AS tipe_pegawai
        FROM karyawan k
        LEFT JOIN tipe_pegawai tp ON k.id_tipe = tp.id_tipe
        WHERE k.role = 'karyawan'";

$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        array_push($data, $row);
    }
}

echo json_encode($data);
mysqli_close($koneksi);
?>
