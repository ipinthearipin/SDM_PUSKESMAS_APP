<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kodeKaryawan'];
$tanggalAbsen = $_POST['tanggalAbsen']; // format: d-m-Y\TH:i:s
$type = $_POST['type'];
$lokasiKerja = $_POST['lokasi_kerja'];

// Format tanggal
$dateTime = DateTime::createFromFormat('d-m-Y\TH:i:s', $tanggalAbsen);
if (!$dateTime) {
    echo json_encode(["message" => "Format tanggal tidak valid"]);
    exit;
}
$formattedDateTime = $dateTime->format('Y-m-d H:i:s');

// Simpan ke tabel absen
$queryInsert = "INSERT INTO absen (kode_karyawan, tanggal_absen, type, lokasi_kerja) VALUES (?, ?, ?, ?)";
$stmtInsert = mysqli_prepare($koneksi, $queryInsert);
mysqli_stmt_bind_param($stmtInsert, "ssss", $kodeKaryawan, $formattedDateTime, $type, $lokasiKerja);
$resultInsert = mysqli_stmt_execute($stmtInsert);

if ($resultInsert) {
    $lastId = mysqli_insert_id($koneksi);

    // Update keterangan berdasarkan shift
    $queryUpdate = "
    UPDATE absen a
    JOIN (
        SELECT sk.kode_karyawan, sk.tanggal_shift, jk.jam_masuk, jk.jam_pulang
        FROM shift_karyawan sk
        JOIN jam_kerja jk ON jk.id_jam_kerja = sk.id_jam_kerja
        WHERE sk.kode_karyawan = ? AND sk.tanggal_shift = DATE(?)
    ) shift_info ON a.kode_karyawan = shift_info.kode_karyawan
    SET a.keterangan = 
        CASE
            WHEN a.type = 'in' THEN
                CASE
                    WHEN TIME(a.tanggal_absen) <= shift_info.jam_masuk THEN 'Tepat Waktu'
                    WHEN TIME(a.tanggal_absen) > shift_info.jam_masuk THEN 
                        CONCAT('Terlambat (', TIME_FORMAT(TIMEDIFF(TIME(a.tanggal_absen), shift_info.jam_masuk), '%H jam %i menit %s detik'), ')')
                END

            WHEN a.type = 'out' THEN
                CASE
                    WHEN shift_info.jam_pulang < shift_info.jam_masuk THEN
                        CASE
                            WHEN a.tanggal_absen >= TIMESTAMP(DATE(shift_info.tanggal_shift) + INTERVAL 1 DAY + INTERVAL TIME_TO_SEC(shift_info.jam_pulang) SECOND) THEN 'Pulang Tepat Waktu'
                            WHEN a.tanggal_absen < TIMESTAMP(DATE(shift_info.tanggal_shift) + INTERVAL 1 DAY + INTERVAL TIME_TO_SEC(shift_info.jam_pulang) SECOND) THEN
                                CONCAT('Pulang Lebih Cepat (', 
                                    TIME_FORMAT(
                                        TIMEDIFF(
                                            TIMESTAMP(DATE(shift_info.tanggal_shift) + INTERVAL 1 DAY + INTERVAL TIME_TO_SEC(shift_info.jam_pulang) SECOND), 
                                            a.tanggal_absen
                                        ), '%H jam %i menit %s detik'
                                    ), 
                                ')')
                        END
                    ELSE
                        CASE
                            WHEN TIME(a.tanggal_absen) >= shift_info.jam_pulang THEN 'Pulang Tepat Waktu'
                            WHEN TIME(a.tanggal_absen) < shift_info.jam_pulang THEN 
                                CONCAT('Pulang Lebih Cepat (', TIME_FORMAT(TIMEDIFF(shift_info.jam_pulang, TIME(a.tanggal_absen)), '%H jam %i menit %s detik'), ')')
                        END
                END
        END
    WHERE a.id_absen = ?";

    $stmtUpdate = mysqli_prepare($koneksi, $queryUpdate);
    mysqli_stmt_bind_param($stmtUpdate, "ssi", $kodeKaryawan, $formattedDateTime, $lastId);
    $resultUpdate = mysqli_stmt_execute($stmtUpdate);

    if ($resultUpdate) {
        $data = array("message" => "Data Berhasil Diupload dan Diperbarui");
    } else {
        $data = array("message" => "Upload berhasil, tapi update gagal: " . mysqli_error($koneksi));
    }
} else {
    $data = array("message" => "Upload gagal: " . mysqli_error($koneksi));
}

echo json_encode($data);
?>
