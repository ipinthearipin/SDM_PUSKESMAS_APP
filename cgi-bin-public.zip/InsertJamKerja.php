<?php
include 'koneksi.php';
header("Content-Type: application/json");

$namaJam = $_POST['nama_jam'];
$namaTipe = $_POST['nama_tipe'];
$jamMasuk = $_POST['jam_masuk']; // format: HH:MM
$jamPulang = $_POST['jam_pulang']; // format: HH:MM

// Tambahkan detik ke format waktu jika hanya HH:MM
if (strlen($jamMasuk) == 5) {
    $jamMasuk .= ':00';
}
if (strlen($jamPulang) == 5) {
    $jamPulang .= ':00';
}

// Ambil id_tipe berdasarkan nama_tipe
$queryTipe = "SELECT id_tipe FROM tipe_pegawai WHERE nama_tipe = ?";
$stmtTipe = $koneksi->prepare($queryTipe);
$stmtTipe->bind_param("s", $namaTipe);
$stmtTipe->execute();
$resultTipe = $stmtTipe->get_result();

if ($resultTipe->num_rows > 0) {
    $rowTipe = $resultTipe->fetch_assoc();
    $idTipe = $rowTipe['id_tipe'];

    // Insert ke jam_kerja
    $queryInsert = "INSERT INTO jam_kerja (nama_jam, id_tipe, jam_masuk, jam_pulang) VALUES (?, ?, ?, ?)";
    $stmtInsert = $koneksi->prepare($queryInsert);
    $stmtInsert->bind_param("siss", $namaJam, $idTipe, $jamMasuk, $jamPulang);
    $success = $stmtInsert->execute();

    if ($success) {
        echo json_encode(["message" => "Data jam kerja berhasil ditambahkan."]);
    } else {
        echo json_encode(["error" => "Gagal menambahkan jam kerja."]);
    }

} else {
    echo json_encode(["error" => "Tipe pegawai tidak ditemukan."]);
}

$koneksi->close();
?>
