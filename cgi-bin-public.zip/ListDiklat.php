<?php
include 'koneksi.php';

$kodeKaryawan = $_POST['kodeKaryawan'];
$sql = "SELECT * FROM diklat WHERE kode_karyawan = '$kodeKaryawan'";
$result = $koneksi->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $row["jp"] = $row["durasi"] / 45;
        array_push($data, $row);
    }
}

echo json_encode($data);
mysqli_close($koneksi);
?>
